package jm.midi;

import java.io.PrintStream;
import java.util.Enumeration;
import java.util.Vector;
import jm.midi.event.Event;

public class Track
{
  private Vector eventList = new Vector();

  public void addEvent(Event paramEvent)
  {
    this.eventList.addElement(paramEvent);
  }

  public Vector getEvtList()
  {
    return this.eventList;
  }

  public void print()
  {
    System.out.println("------------------");
    System.out.println("Track");
    Enumeration localEnumeration = this.eventList.elements();
    while (localEnumeration.hasMoreElements())
      Event localEvent = (Event)localEnumeration.nextElement();
  }
}

/* Location:           /Users/Anand/Documents/2015/Summer/Senior Project/jMusic/JARs/jMusic1.6.4.jar
 * Qualified Name:     jm.midi.Track
 * JD-Core Version:    0.6.2
 */