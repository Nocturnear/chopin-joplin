package jm.midi.event;

public abstract interface VoiceEvt extends Event
{
  public abstract short getMidiChannel();

  public abstract void setMidiChannel(short paramShort);
}

/* Location:           /Users/Anand/Documents/2015/Summer/Senior Project/jMusic/JARs/jMusic1.6.4.jar
 * Qualified Name:     jm.midi.event.VoiceEvt
 * JD-Core Version:    0.6.2
 */