package jm.midi;

import jm.midi.event.Event;

public abstract interface MidiInputListener
{
  public abstract void newEvent(Event paramEvent);
}

/* Location:           /Users/Anand/Documents/2015/Summer/Senior Project/jMusic/JARs/jMusic1.6.4.jar
 * Qualified Name:     jm.midi.MidiInputListener
 * JD-Core Version:    0.6.2
 */