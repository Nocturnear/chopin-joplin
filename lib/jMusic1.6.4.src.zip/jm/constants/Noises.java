package jm.constants;

public abstract interface Noises
{
  public static final int WHITE_NOISE = 0;
  public static final int STEP_NOISE = 1;
  public static final int SMOOTH_NOISE = 2;
  public static final int BROWN_NOISE = 3;
  public static final int FRACTAL_NOISE = 4;
}

/* Location:           /Users/Anand/Documents/2015/Summer/Senior Project/jMusic/JARs/jMusic1.6.4.jar
 * Qualified Name:     jm.constants.Noises
 * JD-Core Version:    0.6.2
 */