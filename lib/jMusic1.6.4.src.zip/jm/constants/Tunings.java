package jm.constants;

public abstract interface Tunings
{
  public static final double[] EQUAL = { 1.0D, 1.059D, 1.122D, 1.189D, 1.26D, 1.335D, 1.414D, 1.498D, 1.587D, 1.682D, 1.782D, 1.888D };
  public static final double[] JUST = { 1.0D, 1.067D, 1.125D, 1.2D, 1.25D, 1.333D, 1.406D, 1.5D, 1.6D, 1.667D, 1.8D, 1.875D };
  public static final double[] PYTHAGOREAN = { 1.0D, 1.053D, 1.125D, 1.185D, 1.265D, 1.333D, 1.404D, 1.5D, 1.58D, 1.687D, 1.778D, 1.898D };
  public static final double[] MEAN = { 1.0D, 1.07D, 1.118D, 1.196D, 1.25D, 1.337D, 1.398D, 1.496D, 1.6D, 1.672D, 1.789D, 1.869D };
}

/* Location:           /Users/Anand/Documents/2015/Summer/Senior Project/jMusic/JARs/jMusic1.6.4.jar
 * Qualified Name:     jm.constants.Tunings
 * JD-Core Version:    0.6.2
 */