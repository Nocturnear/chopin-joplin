package jm.constants;

public abstract interface Volumes
{
  public static final int SILENT = 0;
  public static final int PPP = 10;
  public static final int PP = 25;
  public static final int PIANISSIMO = 25;
  public static final int P = 50;
  public static final int MP = 60;
  public static final int MEZZO_PIANO = 60;
  public static final int MF = 70;
  public static final int MEZZO_FORTE = 70;
  public static final int F = 85;
  public static final int FORTE = 85;
  public static final int FF = 100;
  public static final int FORTISSIMO = 100;
  public static final int FFF = 120;
}

/* Location:           /Users/Anand/Documents/2015/Summer/Senior Project/jMusic/JARs/jMusic1.6.4.jar
 * Qualified Name:     jm.constants.Volumes
 * JD-Core Version:    0.6.2
 */