package jm.constants;

public abstract interface Panning
{
  public static final double PAN_CENTER = 0.5D;
  public static final double PAN_CENTRE = 0.5D;
  public static final double PAN_LEFT = 0.0D;
  public static final double PAN_RIGHT = 1.0D;
}

/* Location:           /Users/Anand/Documents/2015/Summer/Senior Project/jMusic/JARs/jMusic1.6.4.jar
 * Qualified Name:     jm.constants.Panning
 * JD-Core Version:    0.6.2
 */