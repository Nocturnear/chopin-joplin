package jm.constants;

public abstract interface Instruments extends ProgramChanges
{
}

/* Location:           /Users/Anand/Documents/2015/Summer/Senior Project/jMusic/JARs/jMusic1.6.4.jar
 * Qualified Name:     jm.constants.Instruments
 * JD-Core Version:    0.6.2
 */