package jm.audio.synth;

public class SpringObject
{
  private int restingLength;
  private double k = 0.002D;

  public SpringObject()
  {
  }

  public SpringObject(double paramDouble)
  {
    this.k = paramDouble;
  }

  public double getCurrentForce(double paramDouble1, double paramDouble2)
  {
    double d1 = -1.0D * (paramDouble2 - paramDouble1 - this.restingLength);
    double d2 = this.k * d1;
    return d2;
  }

  public void setRestingLength(int paramInt)
  {
    this.restingLength = paramInt;
  }
}

/* Location:           /Users/Anand/Documents/2015/Summer/Senior Project/jMusic/JARs/jMusic1.6.4.jar
 * Qualified Name:     jm.audio.synth.SpringObject
 * JD-Core Version:    0.6.2
 */