package jm.audio.synth;

import jm.audio.AOException;
import jm.audio.AudioObject;

public final class NoteBufferReversed extends AudioObject
{
  private float[] noteBuffer;
  private boolean flag = true;
  private int noteBufferPosition;

  public NoteBufferReversed(AudioObject paramAudioObject)
  {
    super(paramAudioObject, "[Volume]");
  }

  public void build()
  {
    this.noteBuffer = new float[this.numOfSamples];
    this.noteBufferPosition = this.numOfSamples;
    this.flag = true;
  }

  public int work(float[] paramArrayOfFloat)
    throws AOException
  {
    if (this.flag)
    {
      i = this.previous[0].nextWork(this.noteBuffer);
      this.flag = false;
    }
    int i = 0;
    int j = this.noteBufferPosition < paramArrayOfFloat.length ? this.noteBufferPosition : paramArrayOfFloat.length;
    while (i < j)
    {
      paramArrayOfFloat[i] = this.noteBuffer[(--this.noteBufferPosition)];
      i++;
    }
    return i;
  }
}

/* Location:           /Users/Anand/Documents/2015/Summer/Senior Project/jMusic/JARs/jMusic1.6.4.jar
 * Qualified Name:     jm.audio.synth.NoteBufferReversed
 * JD-Core Version:    0.6.2
 */