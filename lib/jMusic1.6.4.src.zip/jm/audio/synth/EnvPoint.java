package jm.audio.synth;

public final class EnvPoint
{
  public float y;
  public float x = -1.0F;
  public int X = -1;

  public EnvPoint(float paramFloat1, float paramFloat2)
  {
    this.y = paramFloat2;
    this.x = paramFloat1;
  }

  public EnvPoint(int paramInt, float paramFloat)
  {
    this.y = paramFloat;
    this.X = paramInt;
  }
}

/* Location:           /Users/Anand/Documents/2015/Summer/Senior Project/jMusic/JARs/jMusic1.6.4.jar
 * Qualified Name:     jm.audio.synth.EnvPoint
 * JD-Core Version:    0.6.2
 */