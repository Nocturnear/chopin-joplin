package jm.audio.synth;

import jm.audio.AOException;
import jm.audio.AudioObject;

public final class Invert extends AudioObject
{
  public Invert(AudioObject paramAudioObject)
  {
    super(paramAudioObject, "[Invert]");
  }

  public int work(float[] paramArrayOfFloat)
    throws AOException
  {
    int i = this.previous[0].nextWork(paramArrayOfFloat);
    for (int j = 0; j < i; j++)
      paramArrayOfFloat[j] *= -1.0F;
    return i;
  }
}

/* Location:           /Users/Anand/Documents/2015/Summer/Senior Project/jMusic/JARs/jMusic1.6.4.jar
 * Qualified Name:     jm.audio.synth.Invert
 * JD-Core Version:    0.6.2
 */