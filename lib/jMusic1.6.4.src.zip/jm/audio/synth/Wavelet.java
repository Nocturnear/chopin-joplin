package jm.audio.synth;

import jm.audio.AOException;
import jm.audio.AudioObject;

public final class Wavelet extends AudioObject
{
  public Wavelet(AudioObject paramAudioObject)
  {
    super(paramAudioObject, "[FGT]");
  }

  public int work(float[] paramArrayOfFloat)
    throws AOException
  {
    return paramArrayOfFloat.length;
  }
}

/* Location:           /Users/Anand/Documents/2015/Summer/Senior Project/jMusic/JARs/jMusic1.6.4.jar
 * Qualified Name:     jm.audio.synth.Wavelet
 * JD-Core Version:    0.6.2
 */