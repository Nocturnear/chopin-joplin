package jm.audio.synth;

import jm.audio.AOException;
import jm.audio.AudioObject;

public final class Smooth extends AudioObject
{
  private float[] prevSampleValues;

  public Smooth(AudioObject paramAudioObject)
  {
    super(paramAudioObject, "[Smooth]");
  }

  public void build()
  {
    this.prevSampleValues = new float[this.channels];
    for (int i = 0; i < this.prevSampleValues.length; i++)
      this.prevSampleValues[i] = 0.0F;
  }

  public int work(float[] paramArrayOfFloat)
    throws AOException
  {
    int i = this.previous[0].nextWork(paramArrayOfFloat);
    int j = 0;
    while (j < i)
    {
      for (int k = 0; k < this.channels; k++)
      {
        paramArrayOfFloat[(j + k)] = (paramArrayOfFloat[(j + k)] * 0.5F + this.prevSampleValues[k] * 0.5F);
        this.prevSampleValues[k] = paramArrayOfFloat[(j + k)];
      }
      j += this.channels;
    }
    return i;
  }
}

/* Location:           /Users/Anand/Documents/2015/Summer/Senior Project/jMusic/JARs/jMusic1.6.4.jar
 * Qualified Name:     jm.audio.synth.Smooth
 * JD-Core Version:    0.6.2
 */