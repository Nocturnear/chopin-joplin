package jm.audio;

public abstract interface AudioChainListener
{
  public abstract void controlChange(float[] paramArrayOfFloat, int paramInt, boolean paramBoolean);
}

/* Location:           /Users/Anand/Documents/2015/Summer/Senior Project/jMusic/JARs/jMusic1.6.4.jar
 * Qualified Name:     jm.audio.AudioChainListener
 * JD-Core Version:    0.6.2
 */