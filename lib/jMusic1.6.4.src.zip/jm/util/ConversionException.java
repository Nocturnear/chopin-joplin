package jm.util;

public class ConversionException extends Exception
{
  public ConversionException()
  {
  }

  public ConversionException(String paramString)
  {
    super(paramString);
  }
}

/* Location:           /Users/Anand/Documents/2015/Summer/Senior Project/jMusic/JARs/jMusic1.6.4.jar
 * Qualified Name:     jm.util.ConversionException
 * JD-Core Version:    0.6.2
 */