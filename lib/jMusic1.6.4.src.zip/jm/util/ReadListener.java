package jm.util;

import jm.music.data.Score;

public abstract interface ReadListener
{
  public abstract Score scoreRead(Score paramScore);

  public abstract void startedReading();

  public abstract void finishedReading();
}

/* Location:           /Users/Anand/Documents/2015/Summer/Senior Project/jMusic/JARs/jMusic1.6.4.jar
 * Qualified Name:     jm.util.ReadListener
 * JD-Core Version:    0.6.2
 */