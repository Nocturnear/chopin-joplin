package jm.util;

import jm.audio.Instrument;
import jm.music.data.Note;
import jm.music.rt.RTLine;

public class AudioRTLine extends RTLine
{
  private boolean firstTime = true;

  public AudioRTLine(String paramString)
  {
    super(new Instrument[] { new AudioSampleInst(paramString) });
  }

  public synchronized Note getNextNote()
  {
    Note localNote;
    if (this.firstTime)
    {
      localNote = new Note(67, 1.0D);
      this.firstTime = false;
    }
    else
    {
      localNote = new Note(-2147483648, 1.0D);
    }
    return localNote;
  }
}

/* Location:           /Users/Anand/Documents/2015/Summer/Senior Project/jMusic/JARs/jMusic1.6.4.jar
 * Qualified Name:     jm.util.AudioRTLine
 * JD-Core Version:    0.6.2
 */