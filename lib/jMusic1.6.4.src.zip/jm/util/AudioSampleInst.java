package jm.util;

import jm.audio.Instrument;
import jm.audio.io.SampleIn;

public final class AudioSampleInst extends Instrument
{
  private String fileName;

  public AudioSampleInst(String paramString)
  {
    this.fileName = paramString;
  }

  public void createChain()
  {
    SampleIn localSampleIn = new SampleIn(this, this.fileName, true, true);
  }
}

/* Location:           /Users/Anand/Documents/2015/Summer/Senior Project/jMusic/JARs/jMusic1.6.4.jar
 * Qualified Name:     jm.util.AudioSampleInst
 * JD-Core Version:    0.6.2
 */