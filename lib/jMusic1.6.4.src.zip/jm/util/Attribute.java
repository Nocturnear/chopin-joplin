package jm.util;

class Attribute
{
  private String name;
  private String value;

  public Attribute(String paramString)
  {
    this.name = paramString;
  }

  public String getName()
  {
    return this.name;
  }

  public void setValue(String paramString)
  {
    this.value = paramString;
  }

  public String getValue()
  {
    return this.value;
  }
}

/* Location:           /Users/Anand/Documents/2015/Summer/Senior Project/jMusic/JARs/jMusic1.6.4.jar
 * Qualified Name:     jm.util.Attribute
 * JD-Core Version:    0.6.2
 */