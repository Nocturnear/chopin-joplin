package jm.util;

import java.util.Vector;
import jm.music.data.Note;
import jm.music.data.Part;
import jm.music.data.Phrase;
import jm.music.data.Score;

class XMLParser
{
  private static final XMLStyle DEFAULT_XML_STYLE = new StandardXMLStyle();

  public static String scoreToXMLString(Score paramScore)
  {
    return new StringBuilder().append(DEFAULT_XML_STYLE.initialXMLDeclaration()).append(scoreToXMLString(paramScore, DEFAULT_XML_STYLE)).toString();
  }

  private static String scoreToXMLString(Score paramScore, XMLStyle paramXMLStyle)
  {
    StringBuffer localStringBuffer = new StringBuffer();
    localStringBuffer.append(new StringBuilder().append(paramXMLStyle.getLeftAngleBracket()).append(paramXMLStyle.getScoreTagName()).toString());
    int j;
    if (!paramScore.getTitle().equals("Untitled Score"))
    {
      localStringBuffer.append(new StringBuilder().append(paramXMLStyle.getSpace()).append(paramXMLStyle.getTitleAttributeName()).append("=").append(paramXMLStyle.getDoubleQuote()).toString());
      String str = paramScore.getTitle();
      for (j = 0; j < str.length(); j++)
      {
        char c = str.charAt(j);
        if (c == ' ')
          localStringBuffer.append(paramXMLStyle.getSpace());
        else if (c == '/')
          localStringBuffer.append(paramXMLStyle.getSlash());
        else if (c == '&')
          localStringBuffer.append(paramXMLStyle.getAmpersandInString());
        else if (c == '<')
          localStringBuffer.append(paramXMLStyle.getLeftAngleBracketInString());
        else if (c == '>')
          localStringBuffer.append(paramXMLStyle.getRightAngleBracketInString());
        else if (c == '"')
          localStringBuffer.append(paramXMLStyle.getDoubleQuoteInString());
        else if (c == '#')
          localStringBuffer.append(paramXMLStyle.getHash());
        else if (c == '/')
          localStringBuffer.append(paramXMLStyle.getSlash());
        else if (c == '?')
          localStringBuffer.append(paramXMLStyle.getQuestionMark());
        else if (c == ';')
          localStringBuffer.append(paramXMLStyle.getSemicolon());
        else
          localStringBuffer.append(c);
      }
      localStringBuffer.append(paramXMLStyle.getDoubleQuote());
    }
    if (paramScore.getTempo() != 60.0D)
      localStringBuffer.append(new StringBuilder().append(paramXMLStyle.getSpace()).append(paramXMLStyle.getTempoAttributeName()).append("=").append(paramXMLStyle.getDoubleQuote()).append(paramXMLStyle.limitDecimalPlaces() ? limitDecimalPlaces(paramScore.getTempo(), 2) : Double.toString(paramScore.getTempo())).append(paramXMLStyle.getDoubleQuote()).toString());
    if (paramScore.getKeySignature() != 0)
      localStringBuffer.append(new StringBuilder().append(paramXMLStyle.getSpace()).append(paramXMLStyle.getKeySignatureAttributeName()).append("=").append(paramXMLStyle.getDoubleQuote()).append(Integer.toString(paramScore.getKeySignature())).append(paramXMLStyle.getDoubleQuote()).toString());
    if (paramScore.getKeyQuality() != 0)
      localStringBuffer.append(new StringBuilder().append(paramXMLStyle.getSpace()).append(paramXMLStyle.getKeyQualityAttributeName()).append("=").append(paramXMLStyle.getDoubleQuote()).append(Integer.toString(paramScore.getKeyQuality())).append(paramXMLStyle.getDoubleQuote()).toString());
    if (paramScore.getNumerator() != 4)
      localStringBuffer.append(new StringBuilder().append(paramXMLStyle.getSpace()).append(paramXMLStyle.getNumeratorAttributeName()).append("=").append(paramXMLStyle.getDoubleQuote()).append(Integer.toString(paramScore.getNumerator())).append(paramXMLStyle.getDoubleQuote()).toString());
    if (paramScore.getDenominator() != 4)
      localStringBuffer.append(new StringBuilder().append(paramXMLStyle.getSpace()).append(paramXMLStyle.getDenominatorAttributeName()).append("=").append(paramXMLStyle.getDoubleQuote()).append(Integer.toString(paramScore.getDenominator())).append(paramXMLStyle.getDoubleQuote()).toString());
    int i = paramScore.size();
    if (i == 0)
    {
      localStringBuffer.append(new StringBuilder().append(paramXMLStyle.getSlash()).append(paramXMLStyle.getRightAngleBracket()).toString());
    }
    else
    {
      localStringBuffer.append(paramXMLStyle.getRightAngleBracket());
      for (j = 0; j < paramScore.size(); j++)
        localStringBuffer.append(partToXMLString(paramScore.getPart(j), paramXMLStyle));
      localStringBuffer.append(new StringBuilder().append(paramXMLStyle.getLeftAngleBracket()).append(paramXMLStyle.getSlash()).append(paramXMLStyle.getScoreTagName()).append(paramXMLStyle.getRightAngleBracket()).toString());
    }
    return localStringBuffer.toString();
  }

  public static String partToXMLString(Part paramPart)
  {
    return new StringBuilder().append(DEFAULT_XML_STYLE.initialXMLDeclaration()).append(partToXMLString(paramPart, DEFAULT_XML_STYLE)).toString();
  }

  private static String partToXMLString(Part paramPart, XMLStyle paramXMLStyle)
  {
    StringBuffer localStringBuffer = new StringBuffer();
    localStringBuffer.append(new StringBuilder().append(paramXMLStyle.getLeftAngleBracket()).append(paramXMLStyle.getPartTagName()).toString());
    int j;
    if (!paramPart.getTitle().equals("Untitled Part"))
    {
      localStringBuffer.append(new StringBuilder().append(paramXMLStyle.getSpace()).append(paramXMLStyle.getTitleAttributeName()).append("=").append(paramXMLStyle.getDoubleQuote()).toString());
      String str = paramPart.getTitle();
      for (j = 0; j < str.length(); j++)
      {
        char c = str.charAt(j);
        if (c == ' ')
          localStringBuffer.append(paramXMLStyle.getSpace());
        else if (c == '/')
          localStringBuffer.append(paramXMLStyle.getSlash());
        else if (c == '&')
          localStringBuffer.append(paramXMLStyle.getAmpersandInString());
        else if (c == '<')
          localStringBuffer.append(paramXMLStyle.getLeftAngleBracketInString());
        else if (c == '>')
          localStringBuffer.append(paramXMLStyle.getRightAngleBracketInString());
        else if (c == '"')
          localStringBuffer.append(paramXMLStyle.getDoubleQuoteInString());
        else if (c == '#')
          localStringBuffer.append(paramXMLStyle.getHash());
        else if (c == '?')
          localStringBuffer.append(paramXMLStyle.getQuestionMark());
        else if (c == ';')
          localStringBuffer.append(paramXMLStyle.getSemicolon());
        else
          localStringBuffer.append(c);
      }
      localStringBuffer.append(paramXMLStyle.getDoubleQuote());
    }
    if (paramPart.getChannel() != 0)
      localStringBuffer.append(new StringBuilder().append(paramXMLStyle.getSpace()).append(paramXMLStyle.getChannelAttributeName()).append("=").append(paramXMLStyle.getDoubleQuote()).append(Integer.toString(paramPart.getChannel())).append(paramXMLStyle.getDoubleQuote()).toString());
    if (paramPart.getInstrument() != 0)
      localStringBuffer.append(new StringBuilder().append(paramXMLStyle.getSpace()).append(paramXMLStyle.getInstrumentAttributeName()).append("=").append(paramXMLStyle.getDoubleQuote()).append(Integer.toString(paramPart.getInstrument())).append(paramXMLStyle.getDoubleQuote()).toString());
    if (paramPart.getTempo() != -1.0D)
      localStringBuffer.append(new StringBuilder().append(paramXMLStyle.getSpace()).append(paramXMLStyle.getTempoAttributeName()).append("=").append(paramXMLStyle.getDoubleQuote()).append(paramXMLStyle.limitDecimalPlaces() ? limitDecimalPlaces(paramPart.getTempo(), 2) : Double.toString(paramPart.getTempo())).append(paramXMLStyle.getDoubleQuote()).toString());
    if (paramPart.getKeySignature() != -2147483648)
      localStringBuffer.append(new StringBuilder().append(paramXMLStyle.getSpace()).append(paramXMLStyle.getKeySignatureAttributeName()).append("=").append(paramXMLStyle.getDoubleQuote()).append(Integer.toString(paramPart.getKeySignature())).append(paramXMLStyle.getDoubleQuote()).toString());
    if (paramPart.getKeyQuality() != -2147483648)
      localStringBuffer.append(new StringBuilder().append(paramXMLStyle.getSpace()).append(paramXMLStyle.getKeyQualityAttributeName()).append("=").append(paramXMLStyle.getDoubleQuote()).append(Integer.toString(paramPart.getKeyQuality())).append(paramXMLStyle.getDoubleQuote()).toString());
    if (paramPart.getNumerator() != -2147483648)
      localStringBuffer.append(new StringBuilder().append(paramXMLStyle.getSpace()).append(paramXMLStyle.getNumeratorAttributeName()).append("=").append(paramXMLStyle.getDoubleQuote()).append(Integer.toString(paramPart.getNumerator())).append(paramXMLStyle.getDoubleQuote()).toString());
    if (paramPart.getDenominator() != -2147483648)
      localStringBuffer.append(new StringBuilder().append(paramXMLStyle.getSpace()).append(paramXMLStyle.getDenominatorAttributeName()).append("=").append(paramXMLStyle.getDoubleQuote()).append(Integer.toString(paramPart.getDenominator())).append(paramXMLStyle.getDoubleQuote()).toString());
    if (paramPart.getPan() != 0.5D)
      localStringBuffer.append(new StringBuilder().append(paramXMLStyle.getSpace()).append(paramXMLStyle.getPanAttributeName()).append("=").append(paramXMLStyle.getDoubleQuote()).append(paramXMLStyle.limitDecimalPlaces() ? limitDecimalPlaces(paramPart.getPan(), 2) : Double.toString(paramPart.getPan())).append(paramXMLStyle.getDoubleQuote()).toString());
    int i = paramPart.size();
    if (i == 0)
    {
      localStringBuffer.append(new StringBuilder().append(paramXMLStyle.getSlash()).append(paramXMLStyle.getRightAngleBracket()).toString());
    }
    else
    {
      localStringBuffer.append(paramXMLStyle.getRightAngleBracket());
      for (j = 0; j < paramPart.size(); j++)
        localStringBuffer.append(phraseToXMLString(paramPart.getPhrase(j), paramXMLStyle));
      localStringBuffer.append(new StringBuilder().append(paramXMLStyle.getLeftAngleBracket()).append(paramXMLStyle.getSlash()).append(paramXMLStyle.getPartTagName()).append(paramXMLStyle.getRightAngleBracket()).toString());
    }
    return localStringBuffer.toString();
  }

  public static String phraseToXMLString(Phrase paramPhrase)
  {
    return new StringBuilder().append(DEFAULT_XML_STYLE.initialXMLDeclaration()).append(phraseToXMLString(paramPhrase, DEFAULT_XML_STYLE)).toString();
  }

  private static String phraseToXMLString(Phrase paramPhrase, XMLStyle paramXMLStyle)
  {
    StringBuffer localStringBuffer = new StringBuffer();
    localStringBuffer.append(new StringBuilder().append(paramXMLStyle.getLeftAngleBracket()).append(paramXMLStyle.getPhraseTagName()).toString());
    int j;
    if (!paramPhrase.getTitle().equals("Untitled Phrase"))
    {
      localStringBuffer.append(new StringBuilder().append(paramXMLStyle.getSpace()).append(paramXMLStyle.getTitleAttributeName()).append("=").append(paramXMLStyle.getDoubleQuote()).toString());
      String str = paramPhrase.getTitle();
      for (j = 0; j < str.length(); j++)
      {
        char c = str.charAt(j);
        if (c == ' ')
          localStringBuffer.append(paramXMLStyle.getSpace());
        else if (c == '/')
          localStringBuffer.append(paramXMLStyle.getSlash());
        else if (c == '&')
          localStringBuffer.append(paramXMLStyle.getAmpersandInString());
        else if (c == '<')
          localStringBuffer.append(paramXMLStyle.getLeftAngleBracketInString());
        else if (c == '>')
          localStringBuffer.append(paramXMLStyle.getRightAngleBracketInString());
        else if (c == '"')
          localStringBuffer.append(paramXMLStyle.getDoubleQuoteInString());
        else if (c == '#')
          localStringBuffer.append(paramXMLStyle.getHash());
        else if (c == '?')
          localStringBuffer.append(paramXMLStyle.getQuestionMark());
        else if (c == ';')
          localStringBuffer.append(paramXMLStyle.getSemicolon());
        else
          localStringBuffer.append(c);
      }
      localStringBuffer.append(paramXMLStyle.getDoubleQuote());
    }
    if (paramPhrase.getStartTime() != 0.0D)
      localStringBuffer.append(new StringBuilder().append(paramXMLStyle.getSpace()).append(paramXMLStyle.getStartTimeAttributeName()).append("=").append(paramXMLStyle.getDoubleQuote()).append(paramXMLStyle.limitDecimalPlaces() ? limitDecimalPlaces(paramPhrase.getStartTime(), 2) : Double.toString(paramPhrase.getStartTime())).append(paramXMLStyle.getDoubleQuote()).toString());
    if (paramPhrase.getInstrument() != -1)
      localStringBuffer.append(new StringBuilder().append(paramXMLStyle.getSpace()).append(paramXMLStyle.getInstrumentAttributeName()).append("=").append(paramXMLStyle.getDoubleQuote()).append(Integer.toString(paramPhrase.getInstrument())).append(paramXMLStyle.getDoubleQuote()).toString());
    if (paramPhrase.getPan() != -1.0D)
      localStringBuffer.append(new StringBuilder().append(paramXMLStyle.getSpace()).append(paramXMLStyle.getTempoAttributeName()).append("=").append(paramXMLStyle.getDoubleQuote()).append(paramXMLStyle.limitDecimalPlaces() ? limitDecimalPlaces(paramPhrase.getTempo(), 2) : Double.toString(paramPhrase.getTempo())).append(paramXMLStyle.getDoubleQuote()).toString());
    if (paramPhrase.getAppend())
      localStringBuffer.append(new StringBuilder().append(paramXMLStyle.getSpace()).append(paramXMLStyle.getAppendAttributeName()).append("=").append(paramXMLStyle.getDoubleQuote()).append(paramPhrase.getAppend() ? Boolean.TRUE.toString() : Boolean.FALSE.toString()).append(paramXMLStyle.getDoubleQuote()).toString());
    if (paramPhrase.getPan() != 0.5D)
      localStringBuffer.append(new StringBuilder().append(paramXMLStyle.getSpace()).append(paramXMLStyle.getPanAttributeName()).append("=").append(paramXMLStyle.getDoubleQuote()).append(paramXMLStyle.limitDecimalPlaces() ? limitDecimalPlaces(paramPhrase.getPan(), 2) : Double.toString(paramPhrase.getPan())).append(paramXMLStyle.getDoubleQuote()).toString());
    int i = paramPhrase.size();
    if (i == 0)
    {
      localStringBuffer.append(new StringBuilder().append(paramXMLStyle.getSlash()).append(paramXMLStyle.getRightAngleBracket()).toString());
    }
    else
    {
      localStringBuffer.append(paramXMLStyle.getRightAngleBracket());
      for (j = 0; j < i; j++)
        localStringBuffer.append(noteToXMLString(paramPhrase.getNote(j), paramXMLStyle));
      localStringBuffer.append(new StringBuilder().append(paramXMLStyle.getLeftAngleBracket()).append(paramXMLStyle.getSlash()).append(paramXMLStyle.getPhraseTagName()).append(paramXMLStyle.getRightAngleBracket()).toString());
    }
    return localStringBuffer.toString();
  }

  public static String noteToXMLString(Note paramNote)
  {
    return new StringBuilder().append(DEFAULT_XML_STYLE.initialXMLDeclaration()).append(noteToXMLString(paramNote, DEFAULT_XML_STYLE)).toString();
  }

  private static String noteToXMLString(Note paramNote, XMLStyle paramXMLStyle)
  {
    StringBuffer localStringBuffer = new StringBuffer();
    localStringBuffer.append(new StringBuilder().append(paramXMLStyle.getLeftAngleBracket()).append(paramXMLStyle.getNoteTagName()).toString());
    if (!paramNote.getPitchType())
    {
      if (paramNote.getPitch() != 60)
        localStringBuffer.append(new StringBuilder().append(paramXMLStyle.getSpace()).append(paramXMLStyle.getPitchAttributeName()).append("=").append(paramXMLStyle.getDoubleQuote()).append(Integer.toString(paramNote.getPitch())).append(paramXMLStyle.getDoubleQuote()).toString());
    }
    else
      localStringBuffer.append(new StringBuilder().append(paramXMLStyle.getSpace()).append(paramXMLStyle.getFrequencyAttributeName()).append("=").append(paramXMLStyle.getDoubleQuote()).append(Double.toString(paramNote.getFrequency())).append(paramXMLStyle.getDoubleQuote()).toString());
    if (paramNote.getDynamic() != 85)
      localStringBuffer.append(new StringBuilder().append(paramXMLStyle.getSpace()).append(paramXMLStyle.getDynamicAttributeName()).append("=").append(paramXMLStyle.getDoubleQuote()).append(Integer.toString(paramNote.getDynamic())).append(paramXMLStyle.getDoubleQuote()).toString());
    if (paramNote.getRhythmValue() != 1.0D)
      localStringBuffer.append(new StringBuilder().append(paramXMLStyle.getSpace()).append(paramXMLStyle.getRhythmValueAttributeName()).append("=").append(paramXMLStyle.getDoubleQuote()).append(paramXMLStyle.limitDecimalPlaces() ? limitDecimalPlaces(paramNote.getRhythmValue(), 2) : Double.toString(paramNote.getRhythmValue())).append(paramXMLStyle.getDoubleQuote()).toString());
    if (paramNote.getPan() != 0.5D)
      localStringBuffer.append(new StringBuilder().append(paramXMLStyle.getSpace()).append(paramXMLStyle.getPanAttributeName()).append("=").append(paramXMLStyle.getDoubleQuote()).append(paramXMLStyle.limitDecimalPlaces() ? limitDecimalPlaces(paramNote.getPan(), 2) : Double.toString(paramNote.getPan())).append(paramXMLStyle.getDoubleQuote()).toString());
    if (paramNote.getDuration() != 0.9D)
      localStringBuffer.append(new StringBuilder().append(paramXMLStyle.getSpace()).append(paramXMLStyle.getDurationAttributeName()).append("=").append(paramXMLStyle.getDoubleQuote()).append(paramXMLStyle.limitDecimalPlaces() ? limitDecimalPlaces(paramNote.getDuration(), 2) : Double.toString(paramNote.getDuration())).append(paramXMLStyle.getDoubleQuote()).toString());
    if (paramNote.getOffset() != 0.0D)
      localStringBuffer.append(new StringBuilder().append(paramXMLStyle.getSpace()).append(paramXMLStyle.getOffsetAttributeName()).append("=").append(paramXMLStyle.getDoubleQuote()).append(paramXMLStyle.limitDecimalPlaces() ? limitDecimalPlaces(paramNote.getOffset(), 2) : Double.toString(paramNote.getOffset())).append(paramXMLStyle.getDoubleQuote()).toString());
    if (paramNote.getSampleStartTime() != 0.0D)
      localStringBuffer.append(new StringBuilder().append(paramXMLStyle.getSpace()).append(paramXMLStyle.getSampleStartTimeAttributeName()).append("=").append(paramXMLStyle.getDoubleQuote()).append(paramXMLStyle.limitDecimalPlaces() ? limitDecimalPlaces(paramNote.getSampleStartTime(), 2) : Double.toString(paramNote.getSampleStartTime())).append(paramXMLStyle.getDoubleQuote()).toString());
    localStringBuffer.append(new StringBuilder().append(paramXMLStyle.getSlash()).append(paramXMLStyle.getRightAngleBracket()).toString());
    return localStringBuffer.toString();
  }

  private static String limitDecimalPlaces(double paramDouble, int paramInt)
  {
    String str = Double.toString(paramDouble);
    int i = str.lastIndexOf(".") + paramInt + 1;
    if (i > str.length())
      i = str.length();
    return str.substring(0, i);
  }

  public static Score xmlStringToScore(String paramString)
    throws ConversionException
  {
    String str = preprocessString(paramString);
    Element[] arrayOfElement = xmlStringToElements(str);
    if (arrayOfElement.length != 1)
      throw new ConversionException(new StringBuilder().append("There can be only one root element.  This string invalidly has ").append(arrayOfElement.length).append(" root elements.").toString());
    Element localElement = arrayOfElement[0];
    if (XMLStyles.isValidScoreTag(arrayOfElement[0].getName()))
      return elementToScore(arrayOfElement[0]);
    if (XMLStyles.isValidPartTag(arrayOfElement[0].getName()))
      return new Score(elementToPart(arrayOfElement[0]));
    if (XMLStyles.isValidPhraseTag(arrayOfElement[0].getName()))
      return new Score(new Part(elementToPhrase(arrayOfElement[0])));
    if (XMLStyles.isValidNoteTag(arrayOfElement[0].getName()))
      return new Score(new Part(new Phrase(elementToNote(arrayOfElement[0]))));
    throw new ConversionException(new StringBuilder().append("Unrecognised root element: ").append(arrayOfElement[0].getName()).toString());
  }

  public static Part xmlStringToPart(String paramString)
    throws ConversionException
  {
    String str = preprocessString(paramString);
    Element[] arrayOfElement = xmlStringToElements(str);
    if (arrayOfElement.length != 1)
      throw new ConversionException(new StringBuilder().append("There can be only one root element.  This string invalidly has ").append(arrayOfElement.length).append(" root elements.").toString());
    Element localElement = arrayOfElement[0];
    if (XMLStyles.isValidScoreTag(arrayOfElement[0].getName()))
      throw new ConversionException("This XML string represents a Score, use the xmlStringToScore(String) method instead.");
    if (XMLStyles.isValidPartTag(arrayOfElement[0].getName()))
      return elementToPart(arrayOfElement[0]);
    if (XMLStyles.isValidPhraseTag(arrayOfElement[0].getName()))
      return new Part(elementToPhrase(arrayOfElement[0]));
    if (XMLStyles.isValidNoteTag(arrayOfElement[0].getName()))
      return new Part(new Phrase(elementToNote(arrayOfElement[0])));
    throw new ConversionException(new StringBuilder().append("Unrecognised root element: ").append(arrayOfElement[0].getName()).toString());
  }

  public static Phrase xmlStringToPhrase(String paramString)
    throws ConversionException
  {
    String str = preprocessString(paramString);
    Element[] arrayOfElement = xmlStringToElements(str);
    if (arrayOfElement.length != 1)
      throw new ConversionException(new StringBuilder().append("There can be only one root element.  This string invalidly has ").append(arrayOfElement.length).append(" root elements.").toString());
    Element localElement = arrayOfElement[0];
    if (XMLStyles.isValidScoreTag(arrayOfElement[0].getName()))
      throw new ConversionException("This XML string represents a Score, use the xmlStringToScore(String) method instead.");
    if (XMLStyles.isValidPartTag(arrayOfElement[0].getName()))
      throw new ConversionException("This XML string represents a Part, use the xmlStringToPart(String) method instead.");
    if (XMLStyles.isValidPhraseTag(arrayOfElement[0].getName()))
      return elementToPhrase(arrayOfElement[0]);
    if (XMLStyles.isValidNoteTag(arrayOfElement[0].getName()))
      return new Phrase(elementToNote(arrayOfElement[0]));
    throw new ConversionException(new StringBuilder().append("Unrecognised root element: ").append(arrayOfElement[0].getName()).toString());
  }

  public static Note xmlStringToNote(String paramString)
    throws ConversionException
  {
    String str = preprocessString(paramString);
    Element[] arrayOfElement = xmlStringToElements(str);
    if (arrayOfElement.length != 1)
      throw new ConversionException(new StringBuilder().append("There can be only one root element.  This string invalidly has ").append(arrayOfElement.length).append(" root elements.").toString());
    Element localElement = arrayOfElement[0];
    if (XMLStyles.isValidScoreTag(arrayOfElement[0].getName()))
      throw new ConversionException("This XML string represents a Score, use the xmlStringToScore(String) method instead.");
    if (XMLStyles.isValidPartTag(arrayOfElement[0].getName()))
      throw new ConversionException("This XML string represents a Part, use the xmlStringToPart(String) method instead.");
    if (XMLStyles.isValidPhraseTag(arrayOfElement[0].getName()))
      throw new ConversionException("This XML string represents a Phrase, use the xmlStringToPhrase(String) method instead.");
    if (XMLStyles.isValidNoteTag(arrayOfElement[0].getName()))
      return elementToNote(arrayOfElement[0]);
    throw new ConversionException(new StringBuilder().append("Unrecognised root element: ").append(arrayOfElement[0].getName()).toString());
  }

  private static String preprocessString(String paramString)
    throws ConversionException
  {
    String str1 = paramString;
    for (int i = 0; i < XMLStyles.styles.length; i++)
    {
      localObject = XMLStyles.styles[i].initialXMLDeclaration();
      if (paramString.startsWith((String)localObject))
      {
        str1 = str1.substring(((String)localObject).length());
        break;
      }
    }
    char[] arrayOfChar1 = str1.toCharArray();
    Object localObject = null;
    StandardXMLStyle localStandardXMLStyle = new StandardXMLStyle();
    char[][] arrayOfChar = localStandardXMLStyle.getEncodingsOfReferenceChars();
    char[] arrayOfChar2 = localStandardXMLStyle.getReferenceChars();
    for (int j = 0; j < arrayOfChar.length; j++)
    {
      localObject = new StringBuffer();
      String str2 = new String(arrayOfChar[j]);
      int k = 0;
      for (int m = str1.indexOf(str2); m != -1; m = str1.indexOf(str2, k))
      {
        while (k < m)
        {
          ((StringBuffer)localObject).append(arrayOfChar1[k]);
          k++;
        }
        ((StringBuffer)localObject).append(arrayOfChar2[j]);
        k += 3;
      }
      m = str1.length();
      while (k < m)
      {
        ((StringBuffer)localObject).append(arrayOfChar1[k]);
        k++;
      }
      str1 = ((StringBuffer)localObject).toString();
      arrayOfChar1 = str1.toCharArray();
    }
    return str1;
  }

  private static Score elementToScore(Element paramElement)
    throws ConversionException
  {
    StandardXMLStyle localStandardXMLStyle = new StandardXMLStyle();
    if (!XMLStyles.isValidScoreTag(paramElement.getName()))
      throw new ConversionException(new StringBuilder().append("The root element must have the name '").append(localStandardXMLStyle.getScoreTagName()).append("'.  The invalid name used ").append("was '").append(paramElement.getName()).append("'.").toString());
    Score localScore = new Score();
    String str = XMLStyles.getTitleAttributeValue(paramElement);
    if (!str.equals(""))
      localScore.setTitle(str);
    str = XMLStyles.getTempoAttributeValue(paramElement);
    if (!str.equals(""))
      try
      {
        localScore.setTempo(Double.valueOf(str).doubleValue());
      }
      catch (NumberFormatException localNumberFormatException1)
      {
        throw new ConversionException(new StringBuilder().append("Invalid attribute value: ").append(str).append(".  The ").append("attribute '").append(localStandardXMLStyle.getTempoAttributeName()).append("' of element '").append(localStandardXMLStyle.getScoreTagName()).append("' must represent a Java double.").toString());
      }
    str = XMLStyles.getKeySignatureAttributeValue(paramElement);
    if (!str.equals(""))
      try
      {
        localScore.setKeySignature(Integer.parseInt(str));
      }
      catch (NumberFormatException localNumberFormatException2)
      {
        throw new ConversionException(new StringBuilder().append("Invalid attribute value: ").append(str).append(".  The ").append("attribute '").append(localStandardXMLStyle.getKeySignatureAttributeName()).append("' of element '").append(localStandardXMLStyle.getScoreTagName()).append("' must represent a Java integer.").toString());
      }
    str = XMLStyles.getKeyQualityAttributeValue(paramElement);
    if (!str.equals(""))
      try
      {
        localScore.setKeyQuality(Integer.parseInt(str));
      }
      catch (NumberFormatException localNumberFormatException3)
      {
        throw new ConversionException(new StringBuilder().append("Invalid attribute value: ").append(str).append(".  The ").append("attribute '").append(localStandardXMLStyle.getKeyQualityAttributeName()).append("' of element '").append(localStandardXMLStyle.getScoreTagName()).append("' must represent a Java integer.").toString());
      }
    str = XMLStyles.getNumeratorAttributeValue(paramElement);
    if (!str.equals(""))
      try
      {
        localScore.setNumerator(Integer.parseInt(str));
      }
      catch (NumberFormatException localNumberFormatException4)
      {
        throw new ConversionException(new StringBuilder().append("Invalid attribute value: ").append(str).append(".  The ").append("attribute '").append(localStandardXMLStyle.getNumeratorAttributeName()).append("' of element '").append(localStandardXMLStyle.getScoreTagName()).append("' must represent a Java integer.").toString());
      }
    str = XMLStyles.getDenominatorAttributeValue(paramElement);
    if (!str.equals(""))
      try
      {
        localScore.setDenominator(Integer.parseInt(str));
      }
      catch (NumberFormatException localNumberFormatException5)
      {
        throw new ConversionException(new StringBuilder().append("Invalid attribute value: ").append(str).append(".  The ").append("attribute '").append(localStandardXMLStyle.getDenominatorAttributeName()).append("' of element '").append(localStandardXMLStyle.getScoreTagName()).append("' must represent a Java integer.").toString());
      }
    Element[] arrayOfElement = paramElement.getChildren();
    for (int i = 0; i < arrayOfElement.length; i++)
      if (XMLStyles.isValidPartTag(arrayOfElement[i].getName()))
        localScore.addPart(elementToPart(arrayOfElement[i]));
    return localScore;
  }

  private static Part elementToPart(Element paramElement)
    throws ConversionException
  {
    StandardXMLStyle localStandardXMLStyle = new StandardXMLStyle();
    if (!XMLStyles.isValidPartTag(paramElement.getName()))
      throw new ConversionException(new StringBuilder().append("Invalid element: ").append(paramElement.getName()).append(".  The only ").append("accepted tag name is '").append(localStandardXMLStyle.getPartTagName()).append("'.").toString());
    Part localPart = new Part();
    String str = XMLStyles.getTitleAttributeValue(paramElement);
    if (!str.equals(""))
      localPart.setTitle(str);
    str = XMLStyles.getChannelAttributeValue(paramElement);
    if (!str.equals(""))
      try
      {
        localPart.setChannel(Integer.parseInt(str));
      }
      catch (NumberFormatException localNumberFormatException1)
      {
        throw new ConversionException(new StringBuilder().append("Invalid attribute value: ").append(str).append(".  The ").append("attribute '").append(localStandardXMLStyle.getChannelAttributeName()).append("' of element '").append(localStandardXMLStyle.getPartTagName()).append("' must represent a Java integer.").toString());
      }
    str = XMLStyles.getInstrumentAttributeValue(paramElement);
    if (!str.equals(""))
      try
      {
        localPart.setInstrument(Integer.parseInt(str));
      }
      catch (NumberFormatException localNumberFormatException2)
      {
        throw new ConversionException(new StringBuilder().append("Invalid attribute value: ").append(str).append(".  The ").append("attribute '").append(localStandardXMLStyle.getInstrumentAttributeName()).append("' of element '").append(localStandardXMLStyle.getPartTagName()).append("' must represent a Java integer.").toString());
      }
    str = XMLStyles.getTempoAttributeValue(paramElement);
    if (!str.equals(""))
      try
      {
        localPart.setTempo(Double.valueOf(str).doubleValue());
      }
      catch (NumberFormatException localNumberFormatException3)
      {
        throw new ConversionException(new StringBuilder().append("Invalid attribute value: ").append(str).append(".  The ").append("attribute '").append(localStandardXMLStyle.getTempoAttributeName()).append("' of element '").append(localStandardXMLStyle.getPartTagName()).append("' must represent a Java double.").toString());
      }
    str = XMLStyles.getKeySignatureAttributeValue(paramElement);
    if (!str.equals(""))
      try
      {
        localPart.setKeySignature(Integer.parseInt(str));
      }
      catch (NumberFormatException localNumberFormatException4)
      {
        throw new ConversionException(new StringBuilder().append("Invalid attribute value: ").append(str).append(".  The ").append("attribute '").append(localStandardXMLStyle.getKeySignatureAttributeName()).append("' of element '").append(localStandardXMLStyle.getPartTagName()).append("' must represent a Java integer.").toString());
      }
    str = XMLStyles.getKeyQualityAttributeValue(paramElement);
    if (!str.equals(""))
      try
      {
        localPart.setKeyQuality(Integer.parseInt(str));
      }
      catch (NumberFormatException localNumberFormatException5)
      {
        throw new ConversionException(new StringBuilder().append("Invalid attribute value: ").append(str).append(".  The ").append("attribute '").append(localStandardXMLStyle.getKeyQualityAttributeName()).append("' of element '").append(localStandardXMLStyle.getScoreTagName()).append("' must represent a Java integer.").toString());
      }
    str = XMLStyles.getNumeratorAttributeValue(paramElement);
    if (!str.equals(""))
      try
      {
        localPart.setNumerator(Integer.parseInt(str));
      }
      catch (NumberFormatException localNumberFormatException6)
      {
        throw new ConversionException(new StringBuilder().append("Invalid attribute value: ").append(str).append(".  The ").append("attribute '").append(localStandardXMLStyle.getNumeratorAttributeName()).append("' of element '").append(localStandardXMLStyle.getPartTagName()).append("' must represent a Java integer.").toString());
      }
    str = XMLStyles.getDenominatorAttributeValue(paramElement);
    if (!str.equals(""))
      try
      {
        localPart.setDenominator(Integer.parseInt(str));
      }
      catch (NumberFormatException localNumberFormatException7)
      {
        throw new ConversionException(new StringBuilder().append("Invalid attribute value: ").append(str).append(".  The ").append("attribute '").append(localStandardXMLStyle.getDenominatorAttributeName()).append("' of element '").append(localStandardXMLStyle.getPartTagName()).append("' must represent a Java integer.").toString());
      }
    str = XMLStyles.getPanAttributeValue(paramElement);
    if (!str.equals(""))
      try
      {
        localPart.setPan(Double.valueOf(str).doubleValue());
      }
      catch (NumberFormatException localNumberFormatException8)
      {
        throw new ConversionException(new StringBuilder().append("Invalid attribute value: ").append(str).append(".  The ").append("attribute '").append(localStandardXMLStyle.getPanAttributeName()).append("' of element '").append(localStandardXMLStyle.getPartTagName()).append("' must represent a Java double.").toString());
      }
    Element[] arrayOfElement = paramElement.getChildren();
    for (int i = 0; i < arrayOfElement.length; i++)
      if (XMLStyles.isValidPhraseTag(arrayOfElement[i].getName()))
        localPart.addPhrase(elementToPhrase(arrayOfElement[i]));
    return localPart;
  }

  private static Phrase elementToPhrase(Element paramElement)
    throws ConversionException
  {
    StandardXMLStyle localStandardXMLStyle = new StandardXMLStyle();
    if (!XMLStyles.isValidPhraseTag(paramElement.getName()))
      throw new ConversionException(new StringBuilder().append("Invalid element: ").append(paramElement.getName()).append(".  The only ").append("accepted tag name is '").append(localStandardXMLStyle.getPhraseTagName()).append("'.").toString());
    Phrase localPhrase = new Phrase();
    String str = XMLStyles.getTitleAttributeValue(paramElement);
    if (!str.equals(""))
      try
      {
        localPhrase.setTitle(str);
      }
      catch (NumberFormatException localNumberFormatException1)
      {
        throw new ConversionException(new StringBuilder().append("Invalid attribute value: ").append(str).append(".  The ").append("attribute '").append(localStandardXMLStyle.getTitleAttributeName()).append("' of element '").append(localStandardXMLStyle.getPhraseTagName()).append("' must represent a Java integer.").toString());
      }
    str = XMLStyles.getStartTimeAttributeValue(paramElement);
    if (!str.equals(""))
      try
      {
        localPhrase.setStartTime(Double.valueOf(str).doubleValue());
      }
      catch (NumberFormatException localNumberFormatException2)
      {
        throw new ConversionException(new StringBuilder().append("Invalid attribute value: ").append(str).append(".  The ").append("attribute '").append(localStandardXMLStyle.getStartTimeAttributeName()).append("' of element '").append(localStandardXMLStyle.getPhraseTagName()).append("' must represent a Java double.").toString());
      }
    str = XMLStyles.getInstrumentAttributeValue(paramElement);
    if (!str.equals(""))
      try
      {
        localPhrase.setInstrument(Integer.parseInt(str));
      }
      catch (NumberFormatException localNumberFormatException3)
      {
        throw new ConversionException(new StringBuilder().append("Invalid attribute value: ").append(str).append(".  The ").append("attribute '").append(localStandardXMLStyle.getInstrumentAttributeName()).append("' of element '").append(localStandardXMLStyle.getPhraseTagName()).append("' must represent a Java integer.").toString());
      }
    str = XMLStyles.getTempoAttributeValue(paramElement);
    if (!str.equals(""))
      try
      {
        localPhrase.setTempo(Double.valueOf(str).doubleValue());
      }
      catch (NumberFormatException localNumberFormatException4)
      {
        throw new ConversionException(new StringBuilder().append("Invalid attribute value: ").append(str).append(".  The ").append("attribute '").append(localStandardXMLStyle.getTempoAttributeName()).append("' of element '").append(localStandardXMLStyle.getPhraseTagName()).append("' must represent a Java double.").toString());
      }
    str = XMLStyles.getAppendAttributeValue(paramElement);
    if (!str.equals(""))
      localPhrase.setAppend(new Boolean(str).booleanValue());
    str = XMLStyles.getPanAttributeValue(paramElement);
    if (!str.equals(""))
      try
      {
        localPhrase.setPan(Double.valueOf(str).doubleValue());
      }
      catch (NumberFormatException localNumberFormatException5)
      {
        throw new ConversionException(new StringBuilder().append("Invalid attribute value: ").append(str).append(".  The ").append("attribute '").append(localStandardXMLStyle.getPanAttributeName()).append("' of element '").append(localStandardXMLStyle.getPhraseTagName()).append("' must represent a Java double.").toString());
      }
    Element[] arrayOfElement = paramElement.getChildren();
    for (int i = 0; i < arrayOfElement.length; i++)
      if (XMLStyles.isValidNoteTag(arrayOfElement[i].getName()))
        localPhrase.addNote(elementToNote(arrayOfElement[i]));
    return localPhrase;
  }

  private static Note elementToNote(Element paramElement)
    throws ConversionException
  {
    StandardXMLStyle localStandardXMLStyle = new StandardXMLStyle();
    if (!XMLStyles.isValidNoteTag(paramElement.getName()))
      throw new ConversionException(new StringBuilder().append("Invalid element: ").append(paramElement.getName()).append(".  The only ").append("accepted tag name is '").append(localStandardXMLStyle.getNoteTagName()).append("'.").toString());
    Note localNote = new Note();
    String str = XMLStyles.getPitchAttributeValue(paramElement);
    if (!str.equals(""))
      try
      {
        localNote.setPitch(Integer.parseInt(str));
      }
      catch (NumberFormatException localNumberFormatException1)
      {
        throw new ConversionException(new StringBuilder().append("Invalid attribute value: ").append(str).append(".  The ").append("attribute '").append(localStandardXMLStyle.getPitchAttributeName()).append("' of element '").append(localStandardXMLStyle.getNoteTagName()).append("' must represent a Java integer.").toString());
      }
    str = XMLStyles.getFrequencyAttributeValue(paramElement);
    if (!str.equals(""))
      try
      {
        double d = Double.valueOf(str).doubleValue();
        localNote.setFrequency(d);
      }
      catch (NumberFormatException localNumberFormatException2)
      {
        throw new ConversionException(new StringBuilder().append("Invalid attribute value: ").append(str).append(".  The ").append("attribute '").append(localStandardXMLStyle.getFrequencyAttributeName()).append("' of element '").append(localStandardXMLStyle.getNoteTagName()).append("' must represent a Java double.").toString());
      }
    str = XMLStyles.getDynamicAttributeValue(paramElement);
    if (!str.equals(""))
      try
      {
        localNote.setDynamic(Integer.parseInt(str));
      }
      catch (NumberFormatException localNumberFormatException3)
      {
        throw new ConversionException(new StringBuilder().append("Invalid attribute value: ").append(str).append(".  The ").append("attribute '").append(localStandardXMLStyle.getDynamicAttributeName()).append("' of element '").append(localStandardXMLStyle.getNoteTagName()).append("' must represent a Java integer.").toString());
      }
    str = XMLStyles.getRhythmValueAttributeValue(paramElement);
    if (!str.equals(""))
      try
      {
        localNote.setRhythmValue(Double.valueOf(str).doubleValue());
      }
      catch (NumberFormatException localNumberFormatException4)
      {
        throw new ConversionException(new StringBuilder().append("Invalid attribute value: ").append(str).append(".  The ").append("attribute '").append(localStandardXMLStyle.getRhythmValueAttributeName()).append("' of element '").append(localStandardXMLStyle.getNoteTagName()).append("' must represent a Java double.").toString());
      }
    str = XMLStyles.getPanAttributeValue(paramElement);
    if (!str.equals(""))
      try
      {
        localNote.setPan(Double.valueOf(str).doubleValue());
      }
      catch (NumberFormatException localNumberFormatException5)
      {
        throw new ConversionException(new StringBuilder().append("Invalid attribute value: ").append(str).append(".  The ").append("attribute '").append(localStandardXMLStyle.getPanAttributeName()).append("' of element '").append(localStandardXMLStyle.getNoteTagName()).append("' must represent a Java double.").toString());
      }
    str = XMLStyles.getDurationAttributeValue(paramElement);
    if (!str.equals(""))
      try
      {
        localNote.setDuration(Double.valueOf(str).doubleValue());
      }
      catch (NumberFormatException localNumberFormatException6)
      {
        throw new ConversionException(new StringBuilder().append("Invalid attribute value: ").append(str).append(".  The ").append("attribute '").append(localStandardXMLStyle.getDurationAttributeName()).append("' of element '").append(localStandardXMLStyle.getNoteTagName()).append("' must represent a Java double.").toString());
      }
    str = XMLStyles.getOffsetAttributeValue(paramElement);
    if (!str.equals(""))
      try
      {
        localNote.setOffset(Double.valueOf(str).doubleValue());
      }
      catch (NumberFormatException localNumberFormatException7)
      {
        throw new ConversionException(new StringBuilder().append("Invalid attribute value: ").append(str).append(".  The ").append("attribute '").append(localStandardXMLStyle.getOffsetAttributeName()).append("' of element '").append(localStandardXMLStyle.getNoteTagName()).append("' must represent a Java double.").toString());
      }
    str = XMLStyles.getSampleStartTimeAttributeValue(paramElement);
    if (!str.equals(""))
      try
      {
        localNote.setSampleStartTime(Double.valueOf(str).doubleValue());
      }
      catch (NumberFormatException localNumberFormatException8)
      {
        throw new ConversionException(new StringBuilder().append("Invalid attribute value: ").append(str).append(".  The ").append("attribute '").append(localStandardXMLStyle.getSampleStartTimeAttributeName()).append("' of ").append("element '").append(localStandardXMLStyle.getNoteTagName()).append("' must represent a ").append("Java double.").toString());
      }
    return localNote;
  }

  private static Element[] xmlStringToElements(String paramString)
    throws ConversionException
  {
    Vector localVector = new Vector();
    StandardXMLStyle localStandardXMLStyle = new StandardXMLStyle();
    char[][] arrayOfChar = localStandardXMLStyle.getEncodingsOfValueReferenceChars();
    char[] arrayOfChar1 = localStandardXMLStyle.getValueReferenceChars();
    try
    {
      int i = 0;
      if (paramString.charAt(i++) != '<')
        throw new ConversionException("XML String does not begin with '<'");
      StringBuffer localStringBuffer1 = new StringBuffer();
      for (char c = paramString.charAt(i++); (c != ' ') && (c != '/') && (c != '>'); c = paramString.charAt(i++))
        localStringBuffer1.append(c);
      Element localElement = new Element(localStringBuffer1.toString());
      while (c == ' ')
      {
        StringBuffer localStringBuffer2 = new StringBuffer();
        for (c = paramString.charAt(i++); c != '='; c = paramString.charAt(i++))
        {
          if (c == '/')
            throw new ConversionException(new StringBuilder().append("Illegal character '/' in attribute name of the '").append(localElement.getName()).append("' element.").toString());
          if (c == '>')
            throw new ConversionException(new StringBuilder().append("Illegal character '>' in attribute name of the '").append(localElement.getName()).append("' element.").toString());
          localStringBuffer2.append(c);
        }
        Attribute localAttribute = new Attribute(localStringBuffer2.toString());
        c = paramString.charAt(i++);
        if (c != '"')
          throw new ConversionException(new StringBuilder().append("The value of the '").append(localAttribute.getName()).append("' attribute in the '").append(localElement.getName()).append("' element does not begin with a double-quote ").append("(\").").toString());
        StringBuffer localStringBuffer3 = new StringBuffer();
        label525: for (c = paramString.charAt(i++); c != '"'; c = paramString.charAt(i++))
          for (int m = 0; m < arrayOfChar.length; m++)
            for (int n = 0; n < arrayOfChar[m].length; n++)
              try
              {
                if (arrayOfChar[m][n] != paramString.charAt(i + n - 1))
                {
                  if (m == arrayOfChar.length - 1)
                    localStringBuffer3.append(c);
                  break;
                }
                if (n == arrayOfChar[m].length - 1)
                {
                  i += arrayOfChar[m].length - 1;
                  localStringBuffer3.append(arrayOfChar1[m]);
                  break label525;
                }
              }
              catch (IndexOutOfBoundsException localIndexOutOfBoundsException2)
              {
                if (m == arrayOfChar.length - 1)
                  localStringBuffer3.append(c);
                break;
              }
        localAttribute.setValue(localStringBuffer3.toString());
        localElement.addAttribute(localAttribute);
        c = paramString.charAt(i++);
      }
      if (c == '>')
      {
        int j = paramString.indexOf(new StringBuilder().append("</").append(localElement.getName()).append(">").toString());
        if (j == -1)
          throw new ConversionException(new StringBuilder().append("No closing tag found: </").append(localElement.getName()).append(">").toString());
        localElement.appendChildren(xmlStringToElements(paramString.substring(i, j)));
        i = j + localElement.getName().length() + 3;
      }
      else if (c == '/')
      {
        c = paramString.charAt(i++);
        if (c != '>')
          throw new ConversionException(new StringBuilder().append("Character '>' is expected to terminate the '").append(localElement.getName()).append("' element but was not ").append("found.").toString());
      }
      else
      {
        throw new ConversionException(new StringBuilder().append("Either '>' or '/>' is expected to terminate the '").append(localElement.getName()).append("' element but neither was ").append("found.").toString());
      }
      localVector.addElement(localElement);
      if (i < paramString.length())
      {
        arrayOfElement = xmlStringToElements(paramString.substring(i));
        for (int k = 0; k < arrayOfElement.length; k++)
          localVector.addElement(arrayOfElement[k]);
      }
      Element[] arrayOfElement = new Element[localVector.size()];
      localVector.copyInto(arrayOfElement);
      return arrayOfElement;
    }
    catch (IndexOutOfBoundsException localIndexOutOfBoundsException1)
    {
    }
    throw new ConversionException("Xml string ended prematurely.  Further characters were excepted.");
  }
}

/* Location:           /Users/Anand/Documents/2015/Summer/Senior Project/jMusic/JARs/jMusic1.6.4.jar
 * Qualified Name:     jm.util.XMLParser
 * JD-Core Version:    0.6.2
 */