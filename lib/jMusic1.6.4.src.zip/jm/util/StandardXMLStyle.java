package jm.util;

class StandardXMLStyle extends XMLStyle
{
  public final char[] getReferenceChars()
  {
    return new char[0];
  }

  public final char[][] getEncodingsOfReferenceChars()
  {
    return new char[0][];
  }

  public final char[] getValueReferenceChars()
  {
    return new char[] { '<', '>', '"', '&' };
  }

  public final char[][] getEncodingsOfValueReferenceChars()
  {
    return new char[][] { { '&', 'l', 't', ';' }, { '&', 'g', 't', ';' }, { '&', 'q', 'u', 'o', 't', ';' }, { '&', 'a', 'm', 'p', ';' } };
  }
}

/* Location:           /Users/Anand/Documents/2015/Summer/Senior Project/jMusic/JARs/jMusic1.6.4.jar
 * Qualified Name:     jm.util.StandardXMLStyle
 * JD-Core Version:    0.6.2
 */