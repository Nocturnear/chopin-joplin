package jm.gui.cpn;

public abstract interface KeyChangeListener
{
  public abstract void keyChanged();
}

/* Location:           /Users/Anand/Documents/2015/Summer/Senior Project/jMusic/JARs/jMusic1.6.4.jar
 * Qualified Name:     jm.gui.cpn.KeyChangeListener
 * JD-Core Version:    0.6.2
 */