package jm.gui.show;

import java.awt.Component;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.PrintStream;

public class NoteGraphic extends Component
  implements MouseListener
{
  NoteGraphic()
  {
    addMouseListener(this);
  }

  public void mousePressed(MouseEvent paramMouseEvent)
  {
    System.out.println("X is: " + paramMouseEvent.getX());
  }

  public void mouseClicked(MouseEvent paramMouseEvent)
  {
  }

  public void mouseEntered(MouseEvent paramMouseEvent)
  {
  }

  public void mouseExited(MouseEvent paramMouseEvent)
  {
  }

  public void mouseReleased(MouseEvent paramMouseEvent)
  {
  }
}

/* Location:           /Users/Anand/Documents/2015/Summer/Senior Project/jMusic/JARs/jMusic1.6.4.jar
 * Qualified Name:     jm.gui.show.NoteGraphic
 * JD-Core Version:    0.6.2
 */