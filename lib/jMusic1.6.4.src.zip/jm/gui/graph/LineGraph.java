package jm.gui.graph;

import java.awt.ScrollPane;

public class LineGraph extends ScrollPane
{
  protected GraphCanvas graphCanvas;

  public LineGraph()
  {
    this(new Statistics());
  }

  public LineGraph(Statistics paramStatistics)
  {
    this.graphCanvas = new LineGraphCanvas(paramStatistics);
    add(this.graphCanvas);
  }

  public LineGraph(Statistics[] paramArrayOfStatistics)
  {
    this.graphCanvas = new LineGraphCanvas(paramArrayOfStatistics);
    add(this.graphCanvas);
  }

  public LineGraph(StatisticsList paramStatisticsList)
  {
    this.graphCanvas = new LineGraphCanvas(paramStatisticsList);
    add(this.graphCanvas);
  }

  public void addStatistics(Statistics paramStatistics)
  {
    this.graphCanvas.addStatistics(paramStatistics);
  }
}

/* Location:           /Users/Anand/Documents/2015/Summer/Senior Project/jMusic/JARs/jMusic1.6.4.jar
 * Qualified Name:     jm.gui.graph.LineGraph
 * JD-Core Version:    0.6.2
 */