package jm.music.data;

public class Anchoring
{
  final Phrase anchor;
  final Alignment alignment;
  final double offset;

  Anchoring(Phrase paramPhrase, Alignment paramAlignment, double paramDouble)
  {
    this.anchor = paramPhrase;
    this.alignment = paramAlignment;
    this.offset = paramDouble;
  }

  public final Phrase getAnchor()
  {
    return this.anchor;
  }

  public final Alignment getAlignment()
  {
    return this.alignment;
  }

  public final double getOffset()
  {
    return this.offset;
  }
}

/* Location:           /Users/Anand/Documents/2015/Summer/Senior Project/jMusic/JARs/jMusic1.6.4.jar
 * Qualified Name:     jm.music.data.Anchoring
 * JD-Core Version:    0.6.2
 */