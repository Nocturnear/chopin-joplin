package jm.music.data;

public class Rest extends Note
{
  public Rest()
  {
    this(1.0D);
  }

  public Rest(double paramDouble)
  {
    super(-2147483648, paramDouble);
  }
}

/* Location:           /Users/Anand/Documents/2015/Summer/Senior Project/jMusic/JARs/jMusic1.6.4.jar
 * Qualified Name:     jm.music.data.Rest
 * JD-Core Version:    0.6.2
 */