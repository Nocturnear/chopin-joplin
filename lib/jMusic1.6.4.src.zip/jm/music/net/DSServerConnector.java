package jm.music.net;

import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.io.PrintStream;
import java.net.Socket;

public class DSServerConnector extends Thread
{
  private Socket connection;
  private ObjectInputStream ois;
  private ObjectOutputStream oos;
  private static DSServer server;
  private Object obj;

  public DSServerConnector(Socket paramSocket, DSServer paramDSServer)
  {
    server = paramDSServer;
    this.connection = paramSocket;
    try
    {
      OutputStream localOutputStream = this.connection.getOutputStream();
      this.oos = new ObjectOutputStream(localOutputStream);
      InputStream localInputStream = this.connection.getInputStream();
      this.ois = new ObjectInputStream(localInputStream);
      System.out.println(paramSocket);
    }
    catch (IOException localIOException)
    {
    }
    start();
  }

  public void run()
  {
    try
    {
      while (true)
      {
        Object localObject = this.ois.readObject();
        server.broadCast(localObject, this);
      }
    }
    catch (ClassNotFoundException localClassNotFoundException)
    {
      while (true)
        System.out.println(localClassNotFoundException);
    }
    catch (IOException localIOException)
    {
      System.out.println(localIOException);
      server.deleteConnection(this);
    }
  }

  public void sendObject(Object paramObject)
  {
    try
    {
      this.oos.writeObject(paramObject);
    }
    catch (IOException localIOException)
    {
      server.deleteConnection(this);
    }
  }
}

/* Location:           /Users/Anand/Documents/2015/Summer/Senior Project/jMusic/JARs/jMusic1.6.4.jar
 * Qualified Name:     jm.music.net.DSServerConnector
 * JD-Core Version:    0.6.2
 */