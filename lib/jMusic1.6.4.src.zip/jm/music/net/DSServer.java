package jm.music.net;

import java.io.IOException;
import java.net.ServerSocket;
import java.util.Enumeration;
import java.util.Vector;

public class DSServer extends Thread
{
  private ServerSocket ss;
  private Vector clientConnections = new Vector();

  public DSServer()
  {
    this(6767);
  }

  public DSServer(int paramInt)
  {
    try
    {
      this.ss = new ServerSocket(paramInt);
    }
    catch (IOException localIOException)
    {
    }
    start();
  }

  public void run()
  {
    while (true)
      try
      {
        DSServerConnector localDSServerConnector = new DSServerConnector(this.ss.accept(), this);
        this.clientConnections.addElement(localDSServerConnector);
      }
      catch (IOException localIOException)
      {
      }
  }

  public void broadCast(Object paramObject, DSServerConnector paramDSServerConnector)
  {
    Enumeration localEnumeration = this.clientConnections.elements();
    while (localEnumeration.hasMoreElements())
    {
      DSServerConnector localDSServerConnector = (DSServerConnector)localEnumeration.nextElement();
      if (localDSServerConnector != paramDSServerConnector)
        localDSServerConnector.sendObject(paramObject);
    }
  }

  public void deleteConnection(DSServerConnector paramDSServerConnector)
  {
    this.clientConnections.removeElement(paramDSServerConnector);
    paramDSServerConnector = null;
  }
}

/* Location:           /Users/Anand/Documents/2015/Summer/Senior Project/jMusic/JARs/jMusic1.6.4.jar
 * Qualified Name:     jm.music.net.DSServer
 * JD-Core Version:    0.6.2
 */