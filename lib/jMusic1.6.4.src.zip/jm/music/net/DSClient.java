package jm.music.net;

public abstract interface DSClient
{
  public abstract void newObject(Object paramObject);

  public abstract void setConnection(DSClientConnector paramDSClientConnector);
}

/* Location:           /Users/Anand/Documents/2015/Summer/Senior Project/jMusic/JARs/jMusic1.6.4.jar
 * Qualified Name:     jm.music.net.DSClient
 * JD-Core Version:    0.6.2
 */