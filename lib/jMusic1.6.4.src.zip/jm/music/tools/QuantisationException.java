package jm.music.tools;

public class QuantisationException extends Exception
{
  public QuantisationException()
  {
  }

  public QuantisationException(String paramString)
  {
    super(paramString);
  }
}

/* Location:           /Users/Anand/Documents/2015/Summer/Senior Project/jMusic/JARs/jMusic1.6.4.jar
 * Qualified Name:     jm.music.tools.QuantisationException
 * JD-Core Version:    0.6.2
 */