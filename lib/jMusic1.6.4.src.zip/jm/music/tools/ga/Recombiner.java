package jm.music.tools.ga;

import jm.music.data.Phrase;

public abstract class Recombiner extends GAComponent
{
  public abstract Phrase[] recombine(Phrase[] paramArrayOfPhrase, double[] paramArrayOfDouble, double paramDouble, int paramInt1, int paramInt2);
}

/* Location:           /Users/Anand/Documents/2015/Summer/Senior Project/jMusic/JARs/jMusic1.6.4.jar
 * Qualified Name:     jm.music.tools.ga.Recombiner
 * JD-Core Version:    0.6.2
 */