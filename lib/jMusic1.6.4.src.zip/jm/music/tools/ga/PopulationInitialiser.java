package jm.music.tools.ga;

import jm.music.data.Phrase;

public abstract class PopulationInitialiser extends GAComponent
{
  public abstract Phrase[] initPopulation(Phrase paramPhrase, int paramInt);
}

/* Location:           /Users/Anand/Documents/2015/Summer/Senior Project/jMusic/JARs/jMusic1.6.4.jar
 * Qualified Name:     jm.music.tools.ga.PopulationInitialiser
 * JD-Core Version:    0.6.2
 */