package jm.music.tools.ga;

import jm.music.data.Phrase;

public abstract class ParentSelector extends GAComponent
{
  public abstract Phrase[] selectParents(Phrase[] paramArrayOfPhrase, double[] paramArrayOfDouble);
}

/* Location:           /Users/Anand/Documents/2015/Summer/Senior Project/jMusic/JARs/jMusic1.6.4.jar
 * Qualified Name:     jm.music.tools.ga.ParentSelector
 * JD-Core Version:    0.6.2
 */