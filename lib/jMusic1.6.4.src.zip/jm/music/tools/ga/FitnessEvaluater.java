package jm.music.tools.ga;

import jm.music.data.Phrase;

public abstract class FitnessEvaluater extends GAComponent
{
  public abstract double[] evaluate(Phrase[] paramArrayOfPhrase);
}

/* Location:           /Users/Anand/Documents/2015/Summer/Senior Project/jMusic/JARs/jMusic1.6.4.jar
 * Qualified Name:     jm.music.tools.ga.FitnessEvaluater
 * JD-Core Version:    0.6.2
 */