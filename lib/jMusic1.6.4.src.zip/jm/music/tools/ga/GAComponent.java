package jm.music.tools.ga;

import java.awt.Panel;

public abstract class GAComponent
{
  protected Panel panel = new Panel();
  protected static String label = "Genetic Algorithm Component";

  public Panel getPanel()
  {
    return this.panel;
  }

  public String getLabel()
  {
    return label;
  }
}

/* Location:           /Users/Anand/Documents/2015/Summer/Senior Project/jMusic/JARs/jMusic1.6.4.jar
 * Qualified Name:     jm.music.tools.ga.GAComponent
 * JD-Core Version:    0.6.2
 */