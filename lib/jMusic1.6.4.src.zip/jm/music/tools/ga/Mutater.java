package jm.music.tools.ga;

import jm.music.data.Phrase;

public abstract class Mutater extends GAComponent
{
  public abstract Phrase[] mutate(Phrase[] paramArrayOfPhrase, double paramDouble, int paramInt1, int paramInt2);
}

/* Location:           /Users/Anand/Documents/2015/Summer/Senior Project/jMusic/JARs/jMusic1.6.4.jar
 * Qualified Name:     jm.music.tools.ga.Mutater
 * JD-Core Version:    0.6.2
 */