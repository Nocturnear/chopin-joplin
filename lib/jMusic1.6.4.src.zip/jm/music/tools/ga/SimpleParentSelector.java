package jm.music.tools.ga;

import jm.music.data.Phrase;

public class SimpleParentSelector extends ParentSelector
{
  public Phrase[] selectParents(Phrase[] paramArrayOfPhrase, double[] paramArrayOfDouble)
  {
    Phrase[] arrayOfPhrase = new Phrase[paramArrayOfPhrase.length];
    for (int i = 0; i < paramArrayOfPhrase.length; i++)
      arrayOfPhrase[i] = paramArrayOfPhrase[i].copy();
    return arrayOfPhrase;
  }
}

/* Location:           /Users/Anand/Documents/2015/Summer/Senior Project/jMusic/JARs/jMusic1.6.4.jar
 * Qualified Name:     jm.music.tools.ga.SimpleParentSelector
 * JD-Core Version:    0.6.2
 */