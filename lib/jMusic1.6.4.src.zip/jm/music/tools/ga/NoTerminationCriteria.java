package jm.music.tools.ga;

import jm.music.data.Phrase;

public class NoTerminationCriteria extends TerminationCriteria
{
  public boolean isFinished(Phrase[] paramArrayOfPhrase)
  {
    return false;
  }
}

/* Location:           /Users/Anand/Documents/2015/Summer/Senior Project/jMusic/JARs/jMusic1.6.4.jar
 * Qualified Name:     jm.music.tools.ga.NoTerminationCriteria
 * JD-Core Version:    0.6.2
 */