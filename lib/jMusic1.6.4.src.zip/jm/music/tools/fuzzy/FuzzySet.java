package jm.music.tools.fuzzy;

import java.util.Enumeration;
import java.util.Vector;

public class FuzzySet
{
  private Vector numberList = new Vector();
  private double productSum;
  private double memberSum;

  public void add(FuzzyNumber paramFuzzyNumber)
  {
    this.numberList.addElement(paramFuzzyNumber);
  }

  public void remove(FuzzyNumber paramFuzzyNumber)
  {
    this.numberList.removeElement(paramFuzzyNumber);
  }

  public double getOutput(double paramDouble)
  {
    this.productSum = 0.0D;
    this.memberSum = 0.0D;
    Enumeration localEnumeration = this.numberList.elements();
    while (localEnumeration.hasMoreElements())
    {
      FuzzyNumber localFuzzyNumber = (FuzzyNumber)localEnumeration.nextElement();
      this.productSum += localFuzzyNumber.getPeak() * localFuzzyNumber.getMembership(paramDouble);
      this.memberSum += localFuzzyNumber.getMembership(paramDouble);
    }
    return this.productSum / this.memberSum;
  }
}

/* Location:           /Users/Anand/Documents/2015/Summer/Senior Project/jMusic/JARs/jMusic1.6.4.jar
 * Qualified Name:     jm.music.tools.fuzzy.FuzzySet
 * JD-Core Version:    0.6.2
 */